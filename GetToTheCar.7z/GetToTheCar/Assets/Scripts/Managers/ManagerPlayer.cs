﻿using UnityEngine;
using System.Collections;

public class ManagerPlayer : Singleton<ManagerPlayer>
{
    #region Attributes
    //##################################################
    private float maxSpeed;
    public float MaxSpeed
    {
        get
        {
            return maxSpeed;
        }

        set
        {
            maxSpeed = value;
        }
    }

    private float speed;
    public float Speed
    {
        get
        {
            return speed;
        }

        set
        {
            speed = value;
        }
    }

    private float health;
    public float Health
    {
        get
        {
            return health;
        }

        set
        {
            health = value;
        }
    }

    private bool isMoving;
    public bool IsMoving
    {
        get
        {
            return isMoving;
        }

        set
        {
            isMoving = value;
        }
    }
    //##################################################
    #endregion

    #region Inits
    //##################################################
    public void Init()
    {
        if (isInit) return;

        speed = 0.0f;
        maxSpeed = 15.0f;
        isMoving = false;
        health = 100.0f;

        isInit = true;
    }
    //##################################################
    #endregion
    #region Logic
    //##################################################
    //##################################################
    #endregion
}

﻿using UnityEngine;
using System.Collections;

public class MainGame : Singleton<MainGame>
{

    public GameObject Scripts;

    // po rozpoczeciu sceny
    void Start()
    {
        this.gameObject.AddComponent<ManagerPlayer>();
        // this.Scripts.transform.FindChild("ManagerPlayer").gameObject.AddComponent<ManagerPlayer>();
        ManagerPlayer.Instance.Init();
    }
}

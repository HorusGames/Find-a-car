﻿using UnityEngine;
using System.Collections;

public class Globals : MonoBehaviour
{
    private static  float maxTouchDistance = 350.0f;
    public static float MaxTouchDistance
    {
        get { return maxTouchDistance; }
    }

    private static Vector3 screenCenter = new Vector3(Screen.width / 2, Screen.height / 2, 0.0f);
    public static Vector3 ScreenCenter
    {
        get { return screenCenter; }
    }

}

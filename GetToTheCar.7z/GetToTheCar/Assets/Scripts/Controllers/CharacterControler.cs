﻿using UnityEngine;
using System.Collections;

public class CharacterControler : MonoBehaviour {


    private Vector3 direction;
    private Quaternion _lookRotation;
    private float rotationSpeed = 10.0f;

    void FixedUpdate ()
    {
#if UNITY_EDITOR || UNITY_EDITOR_WIN
        if (ManagerPlayer.Instance.IsMoving)
        {
            Vector3 posPlayer = new Vector3(TouchController.MousePosition.x, 0.0f, TouchController.MousePosition.z);
            Vector3 posTouch = TouchController.MouseScreenPosition;

            ManagerPlayer.Instance.Speed = ManagerPlayer.Instance.MaxSpeed * (Mathf.Clamp01(Vector3.Distance(posTouch, Globals.ScreenCenter) / Globals.MaxTouchDistance));
            transform.position = Vector3.MoveTowards(transform.position, posPlayer, ManagerPlayer.Instance.Speed * Time.fixedDeltaTime);

            Camera.main.transform.position = new Vector3(transform.position.x, transform.position.y + 5, transform.position.z - 10);

            Vector3 targetPostition = new Vector3(TouchController.MousePosition.x,
                                       transform.position.y,
                                       TouchController.MousePosition.z);
         //   Vector3 lerpRpt = Vector3.Lerp(this.transform.position, targetPostition, 2.0f);
            this.transform.LookAt(targetPostition);

            //direction = (posPlayer - transform.position).normalized;
            //_lookRotation = Quaternion.LookRotation(direction);
            //transform.rotation = Quaternion.Slerp(transform.rotation, _lookRotation, Time.deltaTime * rotationSpeed);
        }      
#endif

#if UNITY_ANDROID
        Debug.Log("Obsluga toucha");
#endif
    }


}

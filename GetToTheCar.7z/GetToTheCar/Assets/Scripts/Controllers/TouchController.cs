﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using System;

public class TouchController : MonoBehaviour
{
    static Vector3 mousePoistion;
    public static Vector3 MousePosition
    {
        get { return mousePoistion; }
    }
    static Vector3 mouseScreenPosition;
    public static Vector3 MouseScreenPosition
    {
        get { return mouseScreenPosition; }
    }
    private bool isMoving = false;
    void Start()
    {
        mousePoistion = Camera.main.ScreenToWorldPoint(Input.mousePosition);
    }
    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            ManagerPlayer.Instance.IsMoving = true;
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            mouseScreenPosition = Input.mousePosition;
            if (Physics.Raycast(ray, out hit))
            {
                mousePoistion = hit.point;
            }
        }
        else if(Input.GetMouseButtonUp(0))
        {
            ManagerPlayer.Instance.IsMoving = false;
        }
    }
}
